MAE 3270 • Torque wrench finite-element models

Run in Ansys Mechanical APDL

Use a writable working directory. In Mechanical APDL choose File > Read Input From and select one of the .inp files. Each file contains the complete mesh, material, loads and solution commands. The two final bearing files contain independent positive and negative load cases. The native solver determines which contact springs are carrying load in each direction. The analysis uses inches, pound-force and psi.

The output prefix matches the input filename with underscores in place of hyphens. Each run writes a results database (.rst), a short summary and a CSV of nodal displacements and averaged stresses. The two bearing runs also write all six components of the nodal stress tensor. A missing stress value at a midside node in FULL graphics is a postprocessing convention. The raw native corner stresses determine the extrema and safety checks.

The saved PNGs retain Ansys PowerGraphics with two facets per element edge. By default this display recovers stresses from exterior faces and separates discontinuous surfaces. The tabulated values use /GRAPHICS,FULL and AVPRIN,0, averaging the contributing element stress tensors at each corner before calculating principal values. Differences are largest at an idealized fixed edge. For the same solved displacement field, the maximum tensile S1 values (FULL table / PowerGraphics image, ksi) are 113.399 / 157.638 for the baseline, 68.812 / 71.343 for the positive bearing case, 68.360 / 70.427 for the negative bearing case, 173.392 / 211.445 for the exterior clamp and 74.349 / 118.399 for the volume clamp. These are two recovery conventions applied to the same native results. Ansys documents its display conventions at https://ansyshelp.ansys.com/public/views/secured/corp/v252/en/ans_cmd/Hlp_C_GRAPHICS.html .

Models

baseline-medium.inp reproduces the rectangular M42 beam and square drive from the course drawing. E = 32.0 Mpsi and Poisson ratio = 0.29. The 16.000-in arm takes 37.500 lbf in +Y over its end face. The outside faces and end cap of the upper 0.400 in of the drive have fixed translations. The baseline has a sharp shoulder.

final-positive.inp and final-negative.inp use the R0.100-in production shoulder and Custom 465 H950. E = 28.7 Mpsi and Poisson ratio = 0.28. A uniform lateral traction is integrated over the flat grip face from x = 20 to 24 in (area 1.520 in²). It produces 27.2727 lbf in either direction at x = 22 in, z = 0. The force direction is global. The torque-carrying body is modeled in 3D. Indicator masses and gravity are omitted for this static in-plane calibration.

The default socket model is an idealized seated, frictionless four-wall elastic foundation over z = 0.350 to 0.750 in. The square starts at z = 0.250 in. The socket walls react only outward normal motion of the drive. The opening and closing footprints emerge from the solution. A point at the drive tip supplies the single free UZ datum. With zero net axial force, this datum carries a negligible reaction. The assumed normal stiffness is 110 million lbf/in³, an order-of-magnitude steel compliance estimate equivalent to 28.7 Mpsi divided by 0.261 in. Smooth ramps with zero end slope occupy 0.045 in at the mouth, 0.025 in at the tip and 0.025 in near each flat edge to represent rounded or relieved contact ends. Stiffness is weighted by nodal tributary area. COMBIN39 is oriented so a positive element extension corresponds to motion into a socket wall and produces compression on the drive. No friction, clearance take-up or detailed socket compliance is calibrated from a physical tool.

final-local.inp uses the same final solid mesh and applies the literal fully fixed upper-drive exterior as a fixture sensitivity check. Its mixed free/fixed boundary creates a localized stress peak that rises with mesh refinement. The plate motion relative to the head remains close to the bearing result.

volume-clamp.inp fixes every node inside the upper 0.400 in of the drive, including the mesh-aligned internal cross section at z = 0.350 in. This alternative also exhibits mesh-sensitive stress at the restrained edge. The companion mesh study records all three refinements for this case.

Nodal postprocessing

The displacement at the marked grip center is obtained by evaluating the quadratic displacement interpolant at (22, 0, 0). The conjugate distributed-load displacement is the traction-weighted average over the loaded face. To predict indication, small rigid motions are fitted to displacement samples on each accessory mounting area. Twenty-five sample points span x = −0.30 to 0.34 in and y = ±0.14 in on the head, and x = 18.84 to 19.24 in and y = ±0.12 in on the scale seat. Both lie on z = −0.250 in. The reference tube lies at z = −0.590 in and its raked tip reaches (19, 0, −0.440). The zero mark lies at (19, 0, −0.385). Their global Y difference is about 1.144 in at rated torque. The physical graduation layout transforms the raked tip into the rotated plate frame and gives a projected half-span of about 1.136 in. These fits omit the small self-weight and finite compliance of the pointer.

For yield take the largest instantaneous von Mises stress over both solves. For the opening-mode crack check use the most tensile instantaneous principal stress over both signs. The alternating stress tensor is half the tensor difference at the same material point. Its largest absolute principal value is the maximum normal stress amplitude, and its von Mises value is the supplementary distortion-energy amplitude screen. Performing this subtraction first accounts for the contact footprint switching when torque reverses. The cycle mean is half the tensor sum. The optional mean-stress sensitivity applies 1/n = σa,VM/Sf + max(0, σ1,mean)/Su at each node. It uses an empirical S–N coupon and is a production qualification check.

Reproduction in Python

The companion mesh archives preserve the reference node and element numbering. For the structural baseline use Python 3 with NumPy, SciPy, threadpoolctl and optionally pypardiso. The conditional socket solution uses the same dependencies. Matplotlib renders the portfolio plots. Gmsh 4.15.2 is required only to regenerate a mesh from a STEP solid. The geometry is stored in millimetres and converted to inches on import. High-order meshing can give a slightly different tetrahedralization on another computer. The supplied fixed meshes and .inp files reproduce the reported analyses directly.

  python solve_solid.py baseline-medium.npz
  python socket_bearing.py final-local.npz
  python socket_bearing.py final-local.npz --reversed
  python make_bearing_decks.py final-local.npz
  python native_results.py final-local.npz --positive-nodes final_positive_nodes.csv --negative-nodes final_negative_nodes.csv --positive-tensor final_positive_tensor.csv --negative-tensor final_negative_tensor.csv --out final-native-results.json

The native re-runs and independent small-strain solver share only the mesh and model definition. The Python solve assembles each quadratic solid using four-point tetrahedral integration, independently identifies the unilateral contact footprint, and checks the resultant forces and moments. The primary final stress images are rendered from the native Ansys nodal results.
