"""Write independent positive and negative native MAPDL nonlinear-bearing analyses."""
import argparse
from pathlib import Path

import numpy as np
from mapdl_input import write_deck
from socket_bearing import contact_points


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mesh',type=Path)
    p.add_argument('--out',type=Path,default=Path('.'));p.add_argument('--young',type=float,default=28.7e6)
    p.add_argument('--poisson',type=float,default=.28);p.add_argument('--foundation',type=float,default=110e6)
    a=p.parse_args();a.out.mkdir(exist_ok=True,parents=True);m=np.load(a.mesh)
    contact=contact_points(m,a.foundation,.045,.025,.025)[:4]
    for sign,name in [(1,'final-positive'),(-1,'final-negative')]:
        write_deck(a.out/(name+'.inp'),m,a.young,a.poisson,contact,load_sign=sign)
