"""Independent linear-elastic quadratic-tetrahedral solution of the exported MAPDL mesh.

Units: inch, pound-force, psi.  Run python solve_solid.py final-medium.npz.
The reported nodal tensors average extrapolated element-corner stresses. Midside
stresses are the means of the averaged endpoint tensors (the usual MAPDL display).
"""
import argparse
import json
import os
from pathlib import Path

os.environ.setdefault('MKL_NUM_THREADS','5'); os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import numpy as np
from scipy.sparse import coo_matrix
from scipy.spatial import cKDTree
from threadpoolctl import threadpool_limits


EDGES = np.array([[0,1],[1,2],[2,0],[0,3],[1,3],[2,3]])
BARY_GRAD = np.array([[-1.,-1.,-1.],[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]])
BARY_IP = np.full((4,4),(5-np.sqrt(5))/20)
np.fill_diagonal(BARY_IP,(5+3*np.sqrt(5))/20)
EXTRAP = np.linalg.inv(BARY_IP)


def strain_matrices(coords, bary):
    """Engineering strain matrices for all elements at one tetrahedron point."""
    i,j = EDGES.T
    dnat = np.vstack([(4*bary[:,None]-1)*BARY_GRAD,
                      4*(bary[j,None]*BARY_GRAD[i]+bary[i,None]*BARY_GRAD[j])])
    jac = coords.transpose(0,2,1) @ dnat
    det = np.linalg.det(jac)
    if np.min(det) <= 0: raise ValueError(f'Nonpositive integration Jacobian: {det.min()}')
    grad = dnat @ np.linalg.inv(jac)
    gx,gy,gz = grad.transpose(2,0,1)
    b = np.zeros((len(coords),6,30))
    b[:,0,0::3]=gx; b[:,1,1::3]=gy; b[:,2,2::3]=gz
    b[:,3,0::3]=gy; b[:,3,1::3]=gx
    b[:,4,1::3]=gz; b[:,4,2::3]=gy
    b[:,5,0::3]=gz; b[:,5,2::3]=gx
    return b, det


def isotropic(young,nu):
    mu=young/(2*(1+nu)); lam=young*nu/((1+nu)*(1-2*nu))
    c=np.zeros((6,6)); c[:3,:3]=lam; c[np.diag_indices(3)]+=2*mu
    c[3:,3:]=np.eye(3)*mu
    return c


def assemble(mesh, constants):
    xyz,tet = mesh['coords'],mesh['tet']; n=len(xyz)
    dofs = (tet[:,:,None]*3+np.arange(3,dtype=np.int32)).reshape(-1,30)
    shape=(3*n,3*n); matrix = None; integrated_volume=0.
    for first in range(0,len(tet),1500):
        sl=slice(first,first+1500); ele=xyz[tet[sl]]; dof=dofs[sl]
        kel=np.zeros((len(ele),30,30))
        for g in BARY_IP:
            b, det = strain_matrices(ele,g); integrated_volume += np.sum(det)/24
            kel += ((b.transpose(0,2,1) @ constants) @ b)*(det/24)[:,None,None]
        rr=np.broadcast_to(dof[:,:,None], kel.shape).ravel()
        cc=np.broadcast_to(dof[:,None,:], kel.shape).ravel()
        piece=coo_matrix((kel.ravel(),(rr,cc)),shape=shape).tocsr()
        matrix=piece if matrix is None else matrix+piece
    return matrix, float(integrated_volume)


def direct_solve(stiff, rhs):
    stiff=stiff.tocsr(); stiff.sort_indices()
    try:
        from pypardiso import spsolve
    except (ImportError,OSError):
        from scipy.sparse.linalg import spsolve
    return spsolve(stiff,rhs)


def solve(mesh, constants):
    xyz=mesh['coords']; n=len(xyz); matrix,integrated_volume=assemble(mesh,constants)
    rhs=np.zeros(3*n); rhs[1::3]=mesh['force']*mesh['weights']
    fixed=(mesh['fixed'][:,None]*3+np.arange(3)).ravel()
    free=np.setdiff1d(np.arange(3*n),fixed)
    stiff=matrix[free,:][:,free].tocsr(); stiff.sort_indices()
    print(f'{len(free):,} free DOFs, {stiff.nnz:,} matrix coefficients',flush=True)
    u=np.zeros(3*n); u[free]=direct_solve(stiff,rhs[free]); resid=matrix@u-rhs
    reaction=resid.reshape(-1,3)[mesh['fixed']]
    residual=np.linalg.norm(resid[free])/np.linalg.norm(rhs)
    if residual>1e-5: raise ValueError(f'Equilibrium error: {residual}')
    return u.reshape(-1,3),reaction,residual,float(integrated_volume)


def recover(mesh,u,constants):
    xyz,tet=mesh['coords'],mesh['tet']; s=np.zeros((len(xyz),6)); counts=np.zeros(len(xyz))
    for first in range(0,len(tet),1500):
        conn=tet[first:first+1500]; ele=xyz[conn]; ue=u[conn].reshape(-1,30,1)
        ip=np.empty((len(conn),4,6))
        for k,g in enumerate(BARY_IP):
            b,_=strain_matrices(ele,g); ip[:,k,:]=((constants @ b) @ ue)[:,:,0]
        corners=EXTRAP @ ip; idx=conn[:,:4].ravel()
        np.add.at(s,idx,corners.reshape(-1,6)); np.add.at(counts,idx,1)
    vertices=counts>0; s[vertices]/=counts[vertices,None]
    for k,(i,j) in enumerate(EDGES):
        s[tet[:,4+k]]=(s[tet[:,i]]+s[tet[:,j]])/2
    return s


def stress_metrics(stress):
    xx,yy,zz,xy,yz,xz=stress.T
    mats=np.array([[xx,xy,xz],[xy,yy,yz],[xz,yz,zz]]).transpose(2,0,1)
    principal=np.linalg.eigvalsh(mats)
    vm=np.sqrt(((xx-yy)**2+(yy-zz)**2+(zz-xx)**2)/2+3*(xy**2+yz**2+xz**2))
    return principal[:,2],principal[:,0],xx,vm


def point_displacement(xyz,tet,u,p):
    """Interpolate an exact material-point displacement in a CAD-conforming quadratic tet."""
    target=np.asarray(p); centers=xyz[tet[:,:4]].mean(axis=1)
    nearby=cKDTree(centers).query(target,k=min(100,len(tet)))[1]
    for e in nearby:
        nodes=tet[e]; ele=xyz[nodes]; rs=np.array([.25,.25,.25])
        for _ in range(12):
            bary=np.r_[1-rs.sum(),rs]; i,j=EDGES.T
            n=np.r_[bary*(2*bary-1),4*bary[i]*bary[j]]
            grad=np.vstack([(4*bary[:,None]-1)*BARY_GRAD,
                            4*(bary[j,None]*BARY_GRAD[i]+bary[i,None]*BARY_GRAD[j])])
            delta=np.linalg.solve(ele.T@grad, n@ele-target);rs-=delta
            if np.linalg.norm(delta)<1e-11: break
        if bary.min()>-1e-6 and bary.max()<1.000001 and np.linalg.norm(n@ele-target)<1e-7:
            return n@u[nodes]
    raise ValueError(f'No tetrahedron contains requested material point {p}')


def get_rigid_mount(xyz,surface,u,xrange,yrange):
    """Interpolate the bottom face on a 5 x 5 interior grid, then fit six rigid DOFs."""
    face=surface[np.all(np.abs(xyz[surface,2]+.25)<1e-5,axis=1)]
    target=np.array([[x,y] for x in np.linspace(*xrange,5) for y in np.linspace(*yrange,5)])
    centers=xyz[face[:,:3],:2].mean(axis=1); near=cKDTree(centers).query(target,k=min(30,len(face)))[1]
    td=np.array([[-1.,-1.],[1.,0.],[0.,1.]])
    measured=[]
    for pt, possible in zip(target,near):
        value=None
        for k in possible:
            ids=face[k]; xy=xyz[ids,:2]; rs=np.array([1/3,1/3])
            for _ in range(8):
                b=np.r_[1-rs.sum(),rs]; edge=np.array([[0,1],[1,2],[2,0]]);i,j=edge.T
                h=np.r_[b*(2*b-1),4*b[i]*b[j]]
                d=np.vstack([(4*b[:,None]-1)*td,4*(td[i]*b[j,None]+td[j]*b[i,None])])
                delta=np.linalg.solve(xy.T@d, h@xy-pt); rs-=delta
                if np.linalg.norm(delta)<1e-11: break
            if b.min()>-1e-7 and b.max()<1.0000001 and np.linalg.norm(h@xy-pt)<1e-7:
                value=h@u[ids]; break
        if value is None: raise ValueError(f'Mount point lies outside bottom face: {pt}')
        measured.append(value)
    pos=np.c_[target,np.full(len(target),-.25)]; origin=pos.mean(axis=0)
    dx,dy,dz=(pos-origin).T; z=np.zeros(len(pos)); o=np.ones(len(pos))
    a=np.array([[o,z,z,z,dz,-dy],[z,o,z,-dz,z,dx],[z,z,o,dy,-dx,z]]).transpose(2,0,1).reshape(-1,6)
    coeff=np.linalg.lstsq(a,np.array(measured).ravel(),rcond=None)[0]
    rms=np.sqrt(np.mean((a@coeff - np.asarray(measured).ravel())**2))
    def position(p): return coeff[:3]+np.cross(coeff[3:],np.array(p)-origin)
    return position,coeff,float(rms)


def run(input_file,young,nu,solution=None,suffix='',metadata=None):
    mesh=np.load(input_file); c=isotropic(young,nu)
    if solution is None:
        u,reactions,err,vol=solve(mesh,c); fixed=mesh['fixed']
    else:
        u,reactions,err,vol,fixed=solution
    s=recover(mesh,u,c); s1,s3,sx,vm=stress_metrics(s); xyz=mesh['coords']
    direction=metadata.get('socket_bearing',{}).get('load_sign',1) if metadata else 1
    w=mesh['weights']; load=direction*mesh['force']; length=mesh['length']
    ctr=point_displacement(xyz,mesh['tet'],u,(length,0,0))[1]
    skin_ctr=point_displacement(xyz,mesh['tet'],u,(length,.520 if 'final' in input_file.stem else 0,0))[1]
    report={'length_in':float(length),'torque_in_lbf':float(direction*mesh['torque']),'force_lbf':float(load),
            'young_psi':young,'poisson':nu,'nodes':len(xyz),'elements':len(mesh['tet']),
            'dofs':3*len(xyz),'fixed_nodes':len(fixed),'volume_in3':vol,
            'local_target_in':float(mesh['near_size']),'global_target_in':float(mesh['far_size']),
            'load_area_in2':float(mesh['area']),'load_centroid_in':(w@xyz).tolist(),
            'weighted_load_uy_in':float(w@u[:,1]),'load_point_center_uy_in':float(ctr),
            'load_face_centroid_uy_in':float(skin_ctr),'load_sensitivity_in_per_in_lbf':float(w@u[:,1]/(direction*600)),
            'strain_energy_in_lbf':float(.5*load*np.dot(w,u[:,1])),
            'max_displacement_in':float(np.linalg.norm(u,axis=1).max()),
            'reaction_force_lbf':reactions.sum(axis=0).tolist(),
            'reaction_moment_in_lbf':np.cross(xyz[fixed],reactions).sum(axis=0).tolist(),
            'relative_residual':float(err)}
    masks={'global':np.ones(len(xyz),bool), 'beam_x_1_to_16':(xyz[:,0]>=1)&(xyz[:,0]<=16),
           'drive_shoulder':(xyz[:,0]<.5)&(xyz[:,2]>=.245)&(xyz[:,2]<.343),
           'away_from_support':np.linalg.norm(np.maximum(np.abs(xyz[:,:2])-.1875,0),axis=1)**2+np.maximum(.35-xyz[:,2],0)**2>.05**2}
    for label,mask in masks.items():
        indices=np.flatnonzero(mask); out={}
        for key,values,method in [('s1',s1,np.argmax),('s3',s3,np.argmin),('sx_max',sx,np.argmax),('sx_min',sx,np.argmin),('vm',vm,np.argmax)]:
            i=indices[method(values[indices])]; out[key]={'psi':float(values[i]),'node':int(i+1),'xyz_in':xyz[i].tolist()}
        report[label]=out
    if 'final' in input_file.stem:
        head,ch,rh=get_rigid_mount(xyz,mesh['surface'],u,(-.30,.34),(-.14,.14))
        plate,cp,rp=get_rigid_mount(xyz,mesh['surface'],u,(18.84,19.24),(-.12,.12))
        plate_uy=float(plate((19.,0.,-.385))[1]); needle_uy=float(head((19.,0.,-.440))[1]); throw=plate_uy-needle_uy
        report['scale']={'station_x_in':19.,'head_rotation_rad':ch[3:].tolist(),'plate_rotation_rad':cp[3:].tolist(),
                         'head_fit_rms_in':rh,'plate_fit_rms_in':rp,'plate_zero_uy_in':plate_uy,
                         'pointer_tip_uy_in':needle_uy,'relative_throw_in':throw,
                         'scale_sensitivity_in_per_in_lbf':throw/(direction*600),'head_relative_load_uy_in':float(w@u[:,1]-head((22,0,0))[1]),
                         'head_relative_center_point_uy_in':float(ctr-head((22,0,0))[1])}
    if metadata: report.update(metadata)
    target=input_file.with_name(input_file.stem+suffix); np.savez_compressed(target.parent/(target.name+'-fields.npz'),u=u,stress=s,s1=s1,s3=s3,sx=sx,vm=vm)
    target.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['nodes','elements','weighted_load_uy_in','reaction_moment_in_lbf','global']},indent=2))
    if 'scale' in report: print(json.dumps(report['scale'],indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mesh',type=Path)
    p.add_argument('--young',type=float);p.add_argument('--poisson',type=float);a=p.parse_args()
    isbase='baseline' in a.mesh.stem
    with threadpool_limits(limits=4):
        run(a.mesh,a.young or (32e6 if isbase else 28.7e6),a.poisson or (.29 if isbase else .28))
