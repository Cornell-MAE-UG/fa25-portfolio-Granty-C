"""Render native MAPDL nodal stress results on exactly the CAD-derived solver mesh."""
import argparse
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import colors
from matplotlib.collections import PolyCollection
from matplotlib.colors import Normalize
from matplotlib.patches import Rectangle


BG='#f6f8f6'; INK='#182b34'; MUTED='#435c64'; TEAL='#007c80'; ORANGE='#ba511d'
SUBTRIS=np.array([[0,3,5],[3,1,4],[5,4,2],[3,4,5]])
EDGES=((0,1),(1,2),(2,0),(0,3),(1,3),(2,3))


def camera(direction,roll=0):
    n=np.array(direction,dtype=float);n/=np.linalg.norm(n)
    horizontal=np.array([n[1],-n[0],0]); horizontal/=np.linalg.norm(horizontal)
    if horizontal[0]<0: horizontal=-horizontal
    up=np.array([0.,0.,1.])-n*n[2];up/=np.linalg.norm(up)
    a=np.radians(roll);return np.vstack([horizontal*np.cos(a)-up*np.sin(a),horizontal*np.sin(a)+up*np.cos(a),n])


def view(ax,xyz,skin,cam,vals=None,norm=None,palette=None,point=None,window=None,facecolors=None):
    tr=skin[:,SUBTRIS].reshape(-1,3); points=xyz@cam.T; centers=points[tr].mean(axis=1)
    if window:
        mid=np.array(point)@cam.T; xlo,xhi,ylo,yhi=window
        visible=((centers[:,0]>mid[0]+xlo-.3)&(centers[:,0]<mid[0]+xhi+.3)&
                 (centers[:,1]>mid[1]+ylo-.3)&(centers[:,1]<mid[1]+yhi+.3))
        tr=tr[visible]; centers=centers[visible]
    else: visible=np.ones(len(tr),bool)
    order=np.argsort(centers[:,2]);centers=centers[order];tr=tr[order]
    if vals is None:
        fc=np.repeat(facecolors,4,axis=0)[visible][order].copy()
        v=xyz[tr];cross=np.cross(v[:,1]-v[:,0],v[:,2]-v[:,0]); mag=np.linalg.norm(cross,axis=1)
        dot=np.abs(np.einsum('ij,j->i',cross/np.maximum(mag[:,None],1e-30),cam[2]));fc[:,:3]*=(.77+.23*dot[:,None])
    else:
        fc=palette(norm(vals[tr].mean(axis=1)))
    pc=PolyCollection(points[tr,:2],facecolors=fc,edgecolors='face',linewidths=.065,antialiaseds=False)
    ax.add_collection(pc)
    if window:
        ax.set_xlim(mid[0]+xlo,mid[0]+xhi);ax.set_ylim(mid[1]+ylo,mid[1]+yhi)
    else:
        lim=points[:,:2];span=lim.max(0)-lim.min(0);pad=np.maximum(span*.025,.1)
        ax.set_xlim(lim[:,0].min()-pad[0],lim[:,0].max()+pad[0]);ax.set_ylim(lim[:,1].min()-pad[1],lim[:,1].max()+pad[1]);
    ax.set_aspect('equal');ax.axis('off');return points


def setting():
    plt.rcParams.update({'font.family':'DejaVu Sans','text.color':INK,'axes.labelcolor':INK,'font.size':12,'axes.unicode_minus':False})


def words(fig,x,y,t,fs=12,color=INK,weight='normal',**kw):
    fig.text(x,y,t,fontsize=fs,color=color,weight=weight,va='top',**kw)


def guide(fig,y,x1=.045,x2=.955):
    fig.add_artist(plt.Line2D([x1,x2],[y,y],transform=fig.transFigure,color='#cbd5d4',lw=.8))


def native_stress(path,mesh):
    table=np.genfromtxt(path,delimiter=',',names=True)
    if len(table)!=len(mesh['coords']) or not np.array_equal(table['node'].astype(int),np.arange(1,len(table)+1)):
        raise ValueError('MAPDL nodal file does not match this mesh')
    values=table['s1_psi'].copy()/1000;tet=mesh['tet']
    # FULL graphics reports the corner stress tensor. For smooth color within each facet,
    # interpolate the genuine exported corner S1 to midsides if no value was exported.
    mids=np.unique(tet[:,4:]);corners=np.unique(tet[:,:4])
    if np.max(np.abs(values[mids]))<1e-9:
        for k,(i,j) in enumerate(EDGES):values[tet[:,4+k]]=(values[tet[:,i]]+values[tet[:,j]])/2
    peak=int(corners[np.argmax(values[corners])])
    return values,peak


def stress_plot(mesh,csv,out,title,location):
    xyz,skin=mesh['coords'],mesh['surface']; v,pk=native_stress(csv,mesh); s=xyz[pk]
    peak=v[pk];low=np.floor(v.min()/5)*5;high=np.ceil(peak/5)*5
    norm=Normalize(low,high);cmap=matplotlib.colormaps['viridis']
    fig=plt.figure(figsize=(12,6.95),facecolor=BG); words(fig,.048,.955,'Maximum principal stress',24,weight='bold')
    words(fig,.05,.884,title+'  ·  +600 in·lbf  ·  Undeformed geometry',12,MUTED)
    guide(fig,.837);words(fig,.049,.817,'FULL WRENCH',9,TEAL,'bold')
    ax=fig.add_axes([.055,.585,.89,.18],facecolor=BG)
    view(ax,xyz,skin,camera((-.025,-1,.85),1),v,norm,cmap)
    guide(fig,.563);words(fig,.049,.54,'DRIVE DETAIL',9,TEAL,'bold')
    ax=fig.add_axes([.045,.075,.55,.42],facecolor=BG)
    d=(np.sign(s[0])*1.05,np.sign(s[1])*.95,.92); cam=camera(d)
    pts=view(ax,xyz,skin,cam,v,norm,cmap,point=(0,0,.27),window=(-.65,.82,-.45,.54))
    x,y=pts[pk,:2]
    ax.scatter([x],[y],s=54,facecolor='none',edgecolor='white',linewidth=2,zorder=10)
    ax.scatter([x],[y],s=68,facecolor='none',edgecolor=INK,linewidth=.8,zorder=11)
    words(fig,.626,.494,'Peak tensile normal stress',13,MUTED)
    words(fig,.622,.438,f'{peak:.1f} ksi',28,INK,'bold')
    words(fig,.625,.345,location,11,MUTED,linespacing=1.4)
    cbax=fig.add_axes([.626,.187,.305,.028]);sm=matplotlib.cm.ScalarMappable(norm=norm,cmap=cmap)
    ticks=np.linspace(low,high,5);cb=fig.colorbar(sm,cax=cbax,orientation='horizontal',ticks=ticks)
    cb.ax.tick_params(labelsize=9,color=MUTED,length=3);cb.outline.set_linewidth(.4)
    cb.set_ticklabels([f'{a:g}' for a in ticks]);words(fig,.625,.247,'S₁ (ksi)',10,weight='bold')
    words(fig,.625,.108,f'{len(mesh["tet"]):,} quadratic solid elements\nANSYS MAPDL · full-model nodal averaging',9,MUTED,linespacing=1.4)
    fig.savefig(out,dpi=170,facecolor=BG,pad_inches=0);plt.close(fig)


def bc_plot(mesh,out):
    xyz,skin=mesh['coords'],mesh['surface']; coords=xyz[skin]; fig=plt.figure(figsize=(12,7),facecolor=BG)
    words(fig,.048,.957,'How the wrench was loaded',23,weight='bold')
    words(fig,.05,.885,'Static force balance at the rated torque',12,MUTED);guide(fig,.840)
    words(fig,.049,.816,'PLAN VIEW',9,TEAL,'bold')
    ax=fig.add_axes([.045,.565,.91,.220]);ax.axis('off');ax.set_aspect('equal')
    plan=camera((.00001,0.001,1));plan=np.array([[1.,0,0],[0,1.,0],[0,0,1.]])
    cols=np.tile(colors.to_rgba('#9caeb3'),(len(skin),1));
    onload=np.all(abs(coords[:,:,1]-.520)<1e-5,axis=1)&(coords[:,:,0].mean(axis=1)>19.9)
    cols[onload]=colors.to_rgba(ORANGE)
    view(ax,xyz,skin,plan,facecolors=cols);ax.set_xlim(-1,25);ax.set_ylim(-1.75,2.65)
    ax.plot([20,24],[.52,.52],color=ORANGE,lw=3,solid_capstyle='round')
    for xx in np.arange(20.25,24,.5):
        ax.annotate('',xy=(xx,1.35),xytext=(xx,.55),arrowprops={'arrowstyle':'-|>','color':ORANGE,'lw':1.4,'mutation_scale':9})
    ax.text(22,1.65,'+Y   27.27 lbf',ha='center',fontsize=12,color=ORANGE,weight='bold')
    ax.axvline(0,ymin=.03,ymax=.51,color=TEAL,lw=.9,ls=(0,(2,2)));ax.plot([22,22],[-1.37,.22],color=MUTED,lw=.8,ls=(0,(2,2)))
    ax.annotate('',xy=(0,-1.1),xytext=(22,-1.1),arrowprops={'arrowstyle':'<->','color':MUTED,'lw':1,'mutation_scale':10})
    ax.text(11,-1.1,'  22.00 in to the grip center  ',bbox=dict(facecolor=BG,edgecolor='none',pad=1),va='center',ha='center',fontsize=11,color=INK)
    guide(fig,.532);words(fig,.049,.51,'SOCKET ENGAGEMENT',9,TEAL,'bold')
    c2=np.tile(colors.to_rgba('#b9c7c8'),(len(skin),1));flats=np.zeros(len(skin),bool)
    for axid in [0,1]:
        for sign in [-1,1]:flats|=np.all(np.abs(coords[:,:,axid]-sign*.1875)<1e-5,axis=1)&(np.min(coords[:,:,2],axis=1)>.3499)
    c2[flats]=colors.to_rgba('#008a87');a=fig.add_axes([.06,.075,.425,.38]);cam=camera((-.85,1,.65))
    view(a,xyz,skin,cam,facecolors=c2,point=(0,0,.30),window=(-.55,.63,-.42,.49))
    xmax=.38; xy=np.array([[0.,0,.35],[0.,0,.75]])@cam.T;xt=float(xy[0,0])-.36
    a.annotate('',xy=(xt,xy[0,1]),xytext=(xt,xy[1,1]),arrowprops={'arrowstyle':'<->','color':INK,'lw':1.25,'mutation_scale':9})
    a.text(xt-.012,xy[:,1].mean(),'0.400 in',ha='right',va='center',fontsize=10,color=INK)
    words(fig,.510,.456,'The load is spread over one grip face.',14,weight='bold')
    words(fig,.511,.397,'A uniform traction covers x = 20–24 in. Its resultant\nacts at x = 22 in, so 27.27 lbf produces 600 in·lbf.',10.8,MUTED,linespacing=1.45)
    words(fig,.510,.299,'The socket bears against the drive flats.',14,weight='bold')
    words(fig,.511,.240,'Each wall resists outward motion. The opposite side\ncan open as the torque reverses. One axial datum\nsets UZ = 0 at the drive tip. It carries negligible force.',10.8,MUTED,linespacing=1.45)
    words(fig,.511,.094,'Turquoise shows the four potential contact faces.',9,TEAL)
    fig.savefig(out,dpi=170,facecolor=BG);plt.close(fig)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mesh',type=Path);p.add_argument('out',type=Path)
    p.add_argument('--native',type=Path);p.add_argument('--name',default='Final design');p.add_argument('--location',default='At the transition from the\nhead to the square drive.')
    a=p.parse_args();setting();m=np.load(a.mesh)
    if a.native: stress_plot(m,a.native,a.out,a.name,a.location)
    else: bc_plot(m,a.out)
