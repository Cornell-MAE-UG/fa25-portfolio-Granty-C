"""Measure exact CAD stations and paired-load stress amplitudes from actual MAPDL CSV output.

python native_results.py final-fine.npz --positive-nodes plus_nodes.csv --negative-nodes minus_nodes.csv \
       --positive-tensor plus_tensor.csv --negative-tensor minus_tensor.csv --out results.json
"""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

from solve_solid import get_rigid_mount, point_displacement, stress_metrics


def readcsv(path,n):
    tab=np.genfromtxt(path,delimiter=',',names=True)
    if len(tab)!=n or not np.array_equal(tab['node'].astype(int),np.arange(1,n+1)):
        raise ValueError(f'Nodes do not match: {path}')
    return tab


def summarize(mesh,csv):
    xyz,tet=mesh['coords'],mesh['tet'];tab=readcsv(csv,len(xyz));u=np.column_stack([tab[k] for k in ('ux_in','uy_in','uz_in')]);L=float(mesh['length'])
    wt=float(mesh['weights']@u[:,1]);sign=np.sign(wt);T=sign*600;lpt=(L,0,0);lface=(L,.52 if L==22 else 0,0)
    center=point_displacement(xyz,tet,u,lpt)[1];contactpoint=point_displacement(xyz,tet,u,lface)[1]
    result=dict(torque_in_lbf=T,force_lbf=sign*float(mesh['force']),elements=len(tet),nodes=len(xyz),
                load_patch_uy_in=wt,load_face_center_uy_in=contactpoint,load_axis_center_uy_in=center,
                peak_s1_psi=float(tab['s1_psi'].max()),min_s3_psi=float(tab['s3_psi'].min()),
                peak_vm_psi=float(tab['vm_psi'].max()),peak_sx_psi=float(tab['sx_psi'].max()),min_sx_psi=float(tab['sx_psi'].min()),
                peak_s1_location_in=xyz[np.argmax(tab['s1_psi'])].tolist(),
                peak_vm_location_in=xyz[np.argmax(tab['vm_psi'])].tolist())
    if L==22:
        head,ch,hr=get_rigid_mount(xyz,mesh['surface'],u,(-.30,.34),(-.14,.14));plate,cp,pr=get_rigid_mount(xyz,mesh['surface'],u,(18.84,19.24),(-.12,.12))
        # The reference tube lies at z=-.590. Its raked terminal reaches the actual scale at z=-.440.
        tip_point=np.array([19.,0.,-.440]); p=float(plate((19,0,-.385))[1]);tip=float(head(tip_point)[1]);throw=p-tip
        oh=np.array([.02,0.,-.25]);op=np.array([19.04,0.,-.25]);rh=Rotation.from_rotvec(ch[3:]);rp=Rotation.from_rotvec(cp[3:])
        moved_tip=oh+ch[:3]+rh.apply(tip_point-oh);local_tip=op+rp.inv().apply(moved_tip-op-cp[:3]); mechanical_readout=-float(local_tip[1])
        result.update(head_relative_load_point_uy_in=float(center-head(lpt)[1]),
                      head_relative_load_patch_uy_in=float(wt-head(lpt)[1]),
                      head_yaw_rad=float(ch[5]),plate_zero_uy_in=p,pointer_tip_uy_in=tip,
                      indicator_throw_in=throw,indicator_sensitivity_in_per_in_lbf=float(throw/T),
                      projected_pointer_position_in_plate_in=local_tip.tolist(),
                      printed_scale_signed_excursion_in=mechanical_readout,
                      printed_scale_secant_sensitivity_in_per_in_lbf=mechanical_readout/T)
    return result


def paired_tensors(mesh,plus,minus):
    xyz=mesh['coords'];ids=np.unique(mesh['tet'][:,:4]);n=len(xyz)
    matrices=[]
    for path in (plus,minus):
        tab=readcsv(path,n); matrices.append(np.column_stack([tab[k] for k in ['sx','sy','sz','sxy','syz','sxz']])[ids])
    sa=(matrices[0]-matrices[1])/2;sm=(matrices[0]+matrices[1])/2
    p1,p3,sx,vm=stress_metrics(sa);m1=stress_metrics(sm)[0];maxn=np.maximum(p1,-p3);imap=int(vm.argmax());imn=int(maxn.argmax())
    # The project uses fatigue stress amplitude; the Goodman screen is supplied as
    # an additional sensitivity to tensile local mean at a unilateral contact.
    good=1/(vm/142140.+np.maximum(m1,0)/240000.)
    return {'vm_amplitude_psi':float(vm[imap]),'vm_amplitude_node':int(ids[imap]+1),
            'vm_amplitude_location_in':xyz[ids[imap]].tolist(),'max_normal_amplitude_psi':float(maxn[imn]),
            'normal_amplitude_location_in':xyz[ids[imn]].tolist(),'max_sx_amplitude_psi':float(np.max(abs(sx))),
            'max_mean_principal_at_vm_amplitude_psi':float(m1[imap]),
            'goodman_using_142140_psi_fatigue_240000_psi_ultimate':float(np.min(good))}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mesh',type=Path)
    p.add_argument('--positive-nodes',type=Path,required=True);p.add_argument('--negative-nodes',type=Path)
    p.add_argument('--positive-tensor',type=Path);p.add_argument('--negative-tensor',type=Path);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();mesh=np.load(a.mesh);report={'positive':summarize(mesh,a.positive_nodes)}
    if a.negative_nodes:report['negative']=summarize(mesh,a.negative_nodes)
    if a.positive_tensor and a.negative_tensor:report['stress_amplitude']=paired_tensors(mesh,a.positive_tensor,a.negative_tensor)
    a.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,indent=2))
