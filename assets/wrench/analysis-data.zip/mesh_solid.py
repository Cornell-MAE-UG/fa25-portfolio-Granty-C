"""Mesh an inch-based design from a millimetre STEP file and export both solver inputs.

Example: python mesh_solid.py baseline ../cad-assets/baseline-body.step coarse
Run from this directory. Gmsh is the only CAD/meshing dependency.
"""
import argparse
from pathlib import Path

import gmsh
import numpy as np

from mapdl_input import write_deck


SIZES = {'coarse': (.075, .29), 'medium': (.050, .215), 'fine': (.034, .168),
         'local': (.023, .152), 'audit': (.017, .145)}
TRI_RULE = ((1/6, 1/6, 1/6), (2/3, 1/6, 1/6), (1/6, 2/3, 1/6))
TRI_GRAD = np.array([[-1., -1.], [1., 0.], [0., 1.]])


def triangle_data(coords, triangles):
    """Consistent quadratic triangular-face area weights, including curved edges."""
    weights = np.zeros(len(coords))
    xyz = coords[triangles]
    for r, s, w in TRI_RULE:
        bary = np.array([1-r-s, r, s])
        edges = np.array([[0, 1], [1, 2], [2, 0]])
        i, j = edges.T
        shapes = np.r_[bary * (2*bary-1), 4*bary[i]*bary[j]]
        grad = np.vstack([(4*bary[:, None]-1)*TRI_GRAD,
                          4*(TRI_GRAD[i]*bary[j, None] + TRI_GRAD[j]*bary[i, None])])
        tangent = xyz.transpose(0, 2, 1) @ grad
        areas = np.linalg.norm(np.cross(tangent[:, :, 0], tangent[:, :, 1]), axis=1) * w
        np.add.at(weights, triangles.ravel(), (areas[:, None]*shapes).ravel())
    return weights


def get_geometry(step, name):
    occ = gmsh.model.occ
    bodies = occ.importShapes(str(step.resolve()), highestDimOnly=True)
    if len(bodies) != 1 or bodies[0][0] != 3:
        raise ValueError(f'Expected a single structural solid, found {bodies}')
    occ.dilate(bodies, 0, 0, 0, 1/25.4, 1/25.4, 1/25.4)
    occ.synchronize()
    limits = gmsh.model.getBoundingBox(*bodies[0]); print('STEP bounds in', limits, flush=True)
    if not (15.99 <= limits[3] <= 26 and .749 < limits[5] < .751):
        raise ValueError('STEP size and drive must match the documented inch dimensions.')
    # Partition the drive to put an exact geometric edge at the socket engagement limit.
    # Gmsh retains shared nodes across this internal face: this is still one metal body.
    block = occ.addRectangle(-.52, -.52, .350, 1.04, 1.04)
    entities, _ = occ.fragment(bodies, [(2, block)])
    occ.synchronize()
    vols = [ent for ent in entities if ent[0] == 3]
    all_faces = set(gmsh.model.getBoundary(vols, combined=False, oriented=False))
    loose = [ent for ent in gmsh.model.getEntities(2) if ent not in all_faces]
    if loose:
        occ.remove(loose, recursive=True)
        occ.synchronize()
    external = sorted(tag for dim, tag in gmsh.model.getBoundary(vols, combined=True, oriented=False) if dim == 2)
    fixed_faces, load_faces = [], []
    for tag in external:
        bx = gmsh.model.getBoundingBox(2, tag)
        xc, yc, zc = occ.getCenterOfMass(2, tag)
        flat = [abs(bx[i+3] - bx[i]) < 5e-5 for i in range(3)]
        if bx[2] > .34995 and bx[5] > .3501:
            fixed_faces.append(tag)  # exterior long sides (incl. rounded corners) and end cap
        if name == 'baseline' and flat[0] and abs(xc-16) < 1e-5:
            load_faces.append(tag)
        if name == 'final' and flat[1] and abs(yc-.520) < 1e-5 and abs(xc-22) < 2e-4:
            load_faces.append(tag)
    if len(fixed_faces) < 5 or len(load_faces) != 1:
        raise ValueError(f'Unresolved support/load faces: {fixed_faces=} {load_faces=}')
    print(f'Supporting {len(fixed_faces)} exterior faces, loading {load_faces}', flush=True)
    return external, fixed_faces, load_faces


def make_mesh(step, name, grade, target):
    gmsh.initialize()
    gmsh.option.setNumber('General.Terminal', 1)
    gmsh.option.setNumber('General.Verbosity', 2)
    gmsh.option.setNumber('General.NumThreads', 4)
    try:
        gmsh.model.add(name)
        external, fixed_faces, load_faces = get_geometry(step, name)
        near, far = SIZES[grade]
        field = gmsh.model.mesh.field.add('MathEval')
        # Fine elements at socket shoulder, transitioning to larger elements along the beam.
        rr = 'Sqrt(Max(Sqrt(x*x+y*y)-0.26,0)^2+Max(0.25-z,0)^2+Max(z-0.41,0)^2)'
        gmsh.model.mesh.field.setString(field, 'F', f'Min({far},{near}+0.35*{rr})')
        gmsh.model.mesh.field.setAsBackgroundMesh(field)
        for k, v in {'Mesh.MeshSizeFromPoints':0, 'Mesh.MeshSizeFromCurvature':0,
                     'Mesh.MeshSizeExtendFromBoundary':0, 'Mesh.Algorithm3D':1,
                     'Mesh.MinimumCirclePoints':7, 'Mesh.Optimize':1,
                     'Mesh.SecondOrderLinear':0, 'Mesh.MaxNumThreads3D':1}.items():
            gmsh.option.setNumber(k,v)
        gmsh.model.mesh.generate(3)
        gmsh.model.mesh.setOrder(2)
        element_ids, _ = gmsh.model.mesh.getElementsByType(11)
        scaled = gmsh.model.mesh.getElementQualities(element_ids, 'minSJ')
        if scaled.min() < .03:
            gmsh.model.mesh.optimize('HighOrder', niter=24)
            scaled = gmsh.model.mesh.getElementQualities(element_ids, 'minSJ')
        print(f'Minimum scaled element Jacobian: {scaled.min():.5g}', flush=True)
        if scaled.min() <= 0:
            raise ValueError('Invalid curved elements remain at the CAD boundary')
        tags, xyz, _ = gmsh.model.mesh.getNodes()
        all_xyz = np.zeros((int(max(tags))+1, 3)); all_xyz[tags] = xyz.reshape(-1,3)
        element_ids, conn = gmsh.model.mesh.getElementsByType(11)
        if not len(element_ids): raise ValueError('No quadratic solid elements')
        # Gmsh's final two edge nodes are KL, JL. SOLID187 uses JL, KL.
        conn = conn.reshape(-1,10)[:, [0,1,2,3,4,5,6,7,9,8]]
        used = np.unique(conn); renumber = np.full(len(all_xyz), -1, dtype=np.int32)
        renumber[used] = np.arange(len(used)); coords = all_xyz[used]
        def triangles_on(faces):
            tris = [gmsh.model.mesh.getElementsByType(9, tag)[1].reshape(-1,6) for tag in faces]
            tr = renumber[np.vstack(tris)]
            assert tr.min() >= 0
            return tr
        surface = triangles_on(external); support = triangles_on(fixed_faces); load = triangles_on(load_faces)
        fixed = np.unique(support); weights = triangle_data(coords, load)
        area = weights.sum(); weights /= area
        centroid = weights @ coords
        length = 16. if name == 'baseline' else 22.
        print('Load area, centroid',area,centroid,flush=True)
        if abs(centroid[0]-length)>1e-5 or abs(centroid[2])>1e-5: raise ValueError('Unbalanced force patch')
        tet = renumber[conn]
        data = dict(coords=coords, tet=tet, surface=surface, support_tris=support,
                    load_tris=load, fixed=fixed, weights=weights, area=area,
                    torque=600., force=600./length, length=length, near_size=near, far_size=far)
        np.savez_compressed(target.with_suffix('.npz'), **data)
        return data
    finally:
        gmsh.finalize()


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('model',choices=['baseline','final']); p.add_argument('step', type=Path)
    p.add_argument('grade',choices=SIZES); p.add_argument('--young',type=float); p.add_argument('--poisson',type=float)
    p.add_argument('--out',type=Path,default=Path('.'))
    a = p.parse_args(); out=a.out.resolve(); out.mkdir(exist_ok=True,parents=True)
    base = out / f'{a.model}-{a.grade}'
    data = make_mesh(a.step,a.model,a.grade,base)
    young = a.young or (32e6 if a.model=='baseline' else 28.7e6)
    nu = a.poisson or (.29 if a.model=='baseline' else .28)
    write_deck(base.with_suffix('.inp'), data, young, nu)
    print('Deck and mesh ready:', base, len(data['coords']), 'nodes', len(data['tet']), 'elements',flush=True)
