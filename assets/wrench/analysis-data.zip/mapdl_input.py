"""Write a self-contained native Mechanical APDL SOLID187 input in inch/lbf/psi."""
import numpy as np


def write_deck(path, model, young, poisson, bearing=None, load_sign=1, fixed_volume=False):
    xyz, tet = model['coords'], model['tet']+1
    force, w = load_sign*model['force'], model['weights']
    nnode, nelem = len(xyz), len(tet)
    prefix = path.stem.replace('-', '_')
    with path.open('w', encoding='ascii', newline='\n') as out:
        def lines(*items):
            out.write('\n'.join(items)+'\n')
        lines('! MAE 3270 | horizontal indicating torque wrench | in, lbf, psi',
              '! This complete model is ready for File > Read Input From in MAPDL.',
              '! The STEP body is meshed with conforming 10-node tetrahedra.',
              ('! Upper 0.400 in of drive fixed through its full volume.' if fixed_volume else
               '! Socket engagement fixed on four sides and cap.' if bearing is None else
               '! Four frictionless socket walls have unilateral normal support; opposite walls can open.'),
              'FINISH', '/CLEAR,NOSTART', f'/FILNAME,{prefix}',
              f'/TITLE,MAE 3270 wrench - {prefix}', '/PREP7', 'ET,1,187',
              f'MP,EX,1,{young:.12g}', f'MP,PRXY,1,{poisson:.10g}',
              f'NBLOCK,6,SOLID,{nnode},{nnode}', '(3i9,6e21.13)')
        for i,(x,y,z) in enumerate(xyz,1):
            out.write(f'{i:9d}{0:9d}{0:9d}{x:21.13E}{y:21.13E}{z:21.13E}\n')
        lines('N,R5.3,LOC,       -1,',f'EBLOCK,19,SOLID,{nelem},{nelem}','(19i9)')
        elem_preamble = ''.join(f'{v:9d}' for v in (1,1,1,1,0,0,0,0,10,0))
        for i, nodes in enumerate(tet,1):
            out.write(elem_preamble+f'{i:9d}'+''.join(f'{n:9d}' for n in nodes[:8])+'\n')
            out.write(''.join(f'{n:9d}' for n in nodes[8:])+'\n')
        lines('       -1','ALLSEL,ALL')
        if bearing is None:
            lines('! Fully restrained nodes on the upper 0.400 in of the drive.')
            for i in model['fixed']:
                out.write(f'D,{i+1},ALL,0\n')
        else:
            # COMBIN39 positive stretch corresponds to penetration on each wall. The resulting
            # force ON the drive is compressive. A coincident grounded node sets the wall datum.
            lines('ET,2,39','KEYOPT,2,2,1','KEYOPT,2,3,1','ET,3,39','KEYOPT,3,2,1','KEYOPT,3,3,2')
            nodes,dofs,signs,k=bearing
            for j,(node,dof,sign,stiffness) in enumerate(zip(nodes,dofs,signs,k),1):
                ground=nnode+j; axis=int(dof%3); x,y,z=xyz[node]; ii,jj=(ground,node+1) if sign>0 else (node+1,ground)
                lines(f'N,{ground},{x:.12g},{y:.12g},{z:.12g}',f'D,{ground},U{"XY"[axis]},0',
                      f'R,{j+1},0,0,0.05,{.05*stiffness:.12g}',f'REAL,{j+1}',f'TYPE,{axis+2}',f'E,{ii},{jj}')
            zdatum=np.linalg.norm(xyz-np.array([0,0,.75]),axis=1).argmin()+1
            lines(f'D,{zdatum},UZ,0','ALLSEL,ALL')
        lines('! Equivalent nodal forces integrated over the loaded quadratic triangles.',
              '! Weighted average UY on this same face is conjugate to the applied total force.',
              f'*DIM,loadwt,ARRAY,{nnode}')
        for i in np.flatnonzero(np.abs(w)>1e-13):
            out.write(f'F,{i+1},FY,{w[i]*force:.14g}\nloadwt({i+1})={w[i]:.14g}\n')
        lines('FINISH','/SOLU','ANTYPE,STATIC','NLGEOM,OFF','EQSLV,SPARSE','OUTRES,ALL,LAST')
        if bearing is not None:
            lines('NROPT,FULL','AUTOTS,ON','NSUBST,4,64,1','NEQIT,50','LNSRCH,AUTO')
        lines('SOLVE','FINISH','SAVE','/POST1','SET,LAST','RSYS,0','/GRAPHICS,FULL','AVPRIN,0',
              'ESEL,S,TYPE,,1',f'NSEL,S,NODE,,1,{nnode}',
              f'*DIM,tabn,ARRAY,{nnode},8',f'*DIM,wuy,ARRAY,{nnode}',
              '*VFILL,tabn(1,1),RAMP,1,1','*VGET,tabn(1,2),NODE,1,U,X',
              '*VGET,tabn(1,3),NODE,1,U,Y','*VGET,tabn(1,4),NODE,1,U,Z',
              '*VGET,tabn(1,5),NODE,1,S,1','*VGET,tabn(1,6),NODE,1,S,3',
              '*VGET,tabn(1,7),NODE,1,S,X','*VGET,tabn(1,8),NODE,1,S,EQV',
              '*VOPER,wuy(1),loadwt(1),MULT,tabn(1,3)','*VSCFUN,loaduy,SUM,wuy(1)',
              '*VSCFUN,peakone,MAX,tabn(1,5)','*VSCFUN,leastthr,MIN,tabn(1,6)',
              '*VSCFUN,peakax,MAX,tabn(1,7)','*VSCFUN,minax,MIN,tabn(1,7)',
              '*VSCFUN,peakvm,MAX,tabn(1,8)',f'*CFOPEN,{prefix}_summary,txt',
              '*VWRITE',"('Mechanical APDL SOLID187 | elastic solid | average nodal tensors')",
              '*VWRITE,peakone',"('max_S1_psi = ',E16.8)",
              '*VWRITE,leastthr',"('min_S3_psi = ',E16.8)",
              '*VWRITE,peakax',"('max_SX_psi = ',E16.8)",'*VWRITE,minax',"('min_SX_psi = ',E16.8)",
              '*VWRITE,peakvm',"('max_VM_psi = ',E16.8)",'*VWRITE,loaduy',"('load_patch_UY_in = ',E16.8)",'*CFCLOS',
              f'*CFOPEN,{prefix}_nodes,csv','*VWRITE',"('node,ux_in,uy_in,uz_in,s1_psi,s3_psi,sx_psi,vm_psi')",
              '*VWRITE,tabn(1,1),tabn(1,2),tabn(1,3),tabn(1,4),tabn(1,5),tabn(1,6),tabn(1,7),tabn(1,8)',
              "(F9.0,7(',',E15.7))",'*CFCLOS')
        if bearing is not None:
            lines(f'*DIM,scomp,ARRAY,{nnode},5')
            for i,component in enumerate(['Y','Z','XY','YZ','XZ'],1):
                lines(f'*VGET,scomp(1,{i}),NODE,1,S,{component}')
            lines(f'*CFOPEN,{prefix}_tensor,csv','*VWRITE',"('node,sx,sy,sz,sxy,syz,sxz')",
                  '*VWRITE,tabn(1,1),tabn(1,7),scomp(1,1),scomp(1,2),scomp(1,3),scomp(1,4),scomp(1,5)',
                  "(F9.0,6(',',E15.7))",'*CFCLOS')
        lines('/GRAPHICS,POWER','/EFACET,2',
              '/SHOW,PNG','/VIEW,1,1,-2,1.6','/VUP,1,Z','/ANG,1,15,ZS,1','/DSCALE,1,OFF',
              'PLNSOL,S,1','/SHOW,CLOSE','FINISH')
