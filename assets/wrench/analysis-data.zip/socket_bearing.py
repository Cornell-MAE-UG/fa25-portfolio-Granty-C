"""Sensitivity model: seated, frictionless socket reacting on the four square-drive flats.

An elastic-foundation support reacts only compressive normal motion. Positive
tributary areas use the four subtriangles of each curved six-node boundary facet.
The four-wall response determines contact pressure. No preset torque split is used.
"""
import argparse
from pathlib import Path

import numpy as np
from scipy.sparse import diags
from threadpoolctl import threadpool_limits

from solve_solid import assemble, direct_solve, isotropic, run


def smooth(t):
    t=np.clip(t,0,1);return t*t*(3-2*t)


def contact_points(mesh, bed_modulus, mouth, end, edge):
    xyz,skin=mesh['coords'],mesh['support_tris']; all_nodes=[];all_dofs=[];all_signs=[];all_k=[];all_areas=[]
    for axis in [0,1]:
        for signed in [-1.,1.]:
            tri=skin[np.all(np.abs(xyz[skin,axis]-signed*.1875)<1e-5,axis=1)]
            pieces=tri[:,[[0,3,5],[3,1,4],[5,4,2],[3,4,5]]].reshape(-1,3)
            face=xyz[pieces]; areas=np.linalg.norm(np.cross(face[:,1]-face[:,0],face[:,2]-face[:,0]),axis=1)/2
            shares=np.zeros(len(xyz));np.add.at(shares,pieces.ravel(),np.repeat(areas/3,3))
            nodes=np.flatnonzero(shares); pos=xyz[nodes]
            gain=smooth((pos[:,2]-.35)/mouth)*smooth((.75-pos[:,2])/end)*smooth((.1625-np.abs(pos[:,1-axis]))/edge)
            active=gain>1e-8;nodes=nodes[active];gain=gain[active];ar=shares[nodes]
            all_nodes.extend(nodes); all_dofs.extend(nodes*3+axis);all_signs.extend([signed]*len(nodes))
            all_k.extend(bed_modulus*ar*gain);all_areas.extend(ar)
    return (np.array(all_nodes),np.array(all_dofs),np.array(all_signs),np.array(all_k),np.array(all_areas))


def simulate(mesh,young,nu,modulus,direction,clearance,mouth,end,edge):
    xyz=mesh['coords']; n=len(xyz); k0,vol=assemble(mesh,isotropic(young,nu))
    ids,dof,signs,kstar,areas=contact_points(mesh,modulus,mouth,end,edge)
    fixed_node=np.linalg.norm(xyz-np.array([0,0,.75]),axis=1).argmin()
    refs=[3*fixed_node+2] # one datum removes only the free z-translation
    free=np.setdiff1d(np.arange(3*n),refs); applied=np.zeros(3*n); applied[1::3]=direction*mesh['force']*mesh['weights']
    active=np.ones(len(dof),dtype=bool); u=np.zeros(3*n); converged=False
    for iteration in range(40):
        ks=np.zeros(3*n); np.add.at(ks,dof[active],kstar[active]); rhs=applied.copy()
        if clearance:
            np.add.at(rhs,dof[active],kstar[active]*clearance*signs[active])
        kt=k0+diags(ks); u[free]=direct_solve(kt[free,:][:,free],rhs[free])
        gap=signs*u[dof]-clearance; new=(gap>0)
        changes=np.count_nonzero(active!=new)
        print('Active set',iteration,int(new.sum()),'changes',changes,flush=True)
        if changes==0: converged=True;break
        active=new
    if not converged: raise RuntimeError('Unilateral bearing solution has not converged')
    pforce=np.maximum(gap,0)*kstar
    rf=np.zeros(3*n);np.add.at(rf,dof,-signs*pforce)
    fixed_reaction=(k0@u-applied-rf)[refs];rf[refs]+=fixed_reaction
    residual=np.linalg.norm(k0@u-applied-rf)/np.linalg.norm(applied)
    if residual>1e-5: raise ValueError(f'Residual {residual} exceeds tolerance')
    nr=rf.reshape(-1,3); fi=np.flatnonzero(np.max(np.abs(nr),axis=1)>1e-12)
    perwall=[]
    for axis in [0,1]:
        for normal in [-1.,1.]:
            mask=(dof%3==axis)&(signs==normal)&active
            force=np.zeros((mask.sum(),3));force[:,axis]=-normal*pforce[mask]
            perwall.append({'normal_axis':'XY'[axis],'normal_sign':normal,'active_nodes':int(mask.sum()),
                            'area_in2':float(areas[mask].sum()),'force_lbf':force.sum(axis=0).tolist(),
                            'moment_in_lbf':np.cross(xyz[ids[mask]],force).sum(axis=0).tolist(),
                            'peak_pressure_psi':float((pforce[mask]/areas[mask]).max())})
    contact=dict(bed_modulus_psi_per_in=modulus,clearance_per_face_in=clearance,
                 mouth_transition_in=mouth,tip_transition_in=end,flat_relief_transition_in=edge,
                 active_nodes=int(active.sum()),num_iterations=iteration+1,load_sign=direction,
                 peak_compressive_pressure_psi=float((pforce/areas).max()),z_datum_node=int(fixed_node+1),
                 z_datum_force_lbf=float(fixed_reaction[0]),wall_reactions=perwall)
    native=dict(active_nodes=ids[active],active_dofs=dof[active]%3,active_normal=signs[active],
                active_stiffness=kstar[active],zdatum=int(fixed_node),clearance=clearance,
                calc_contact_force=pforce[active])
    return (u.reshape(-1,3),nr[fi],residual,vol,fi),contact,native


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mesh',type=Path)
    p.add_argument('--modulus',type=float,default=110e6);p.add_argument('--reversed',action='store_true')
    p.add_argument('--young',type=float,default=28.7e6);p.add_argument('--poisson',type=float,default=.28)
    p.add_argument('--gap',type=float,default=0.);p.add_argument('--mouth',type=float,default=.045)
    p.add_argument('--tip',type=float,default=.025);p.add_argument('--corner',type=float,default=.025)
    a=p.parse_args();m=np.load(a.mesh);direction=-1 if a.reversed else 1
    suffix=f'-socket-{a.modulus/1e6:g}'+('-reverse' if a.reversed else '')
    with threadpool_limits(limits=4):
        sol,contact,native=simulate(m,a.young,a.poisson,a.modulus,direction,a.gap,a.mouth,a.tip,a.corner)
        run(a.mesh,a.young,a.poisson,sol,suffix,{'socket_bearing':contact})
        np.savez_compressed(a.mesh.with_name(a.mesh.stem+suffix+'-support.npz'),**native)
