"""Parametric, inch-based CAD for the MAE 3270 beam torque wrench.

Run with Python 3.12 and cadquery 2.8. All STEP outputs use millimetres.
Run the default build to export the structural parts and the complete assembly.
Use --body-only to export just the two structural solids.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import cadquery as cq

MM = 25.4
L = 22.0
HEAD_R = 0.550
B = 0.500
H = 0.360
GRIP_H = 1.040
EDGE_R = 0.060
DRIVE = 0.375
DRIVE_HEIGHT = 0.500
DRIVE_CORNER = 0.025
DRIVE_FILLET = 0.100
FIX_Z = 0.350
SCALE_X = 19.000
POINTER_Z = -0.590
TRACK_RADIUS = 5.040
ARC_CENTER_X = SCALE_X - TRACK_RADIUS
PLATE_R_IN = 4.740
PLATE_R_OUT = 5.600
PLATE_HALF_ANGLE = 19.5
PLATE_END_FILLET = 0.105
OUTPUT = Path(__file__).resolve().parent


def transition(path, x0, y0, x1, y1):
    """Quintic Bezier with zero slope and curvature at both end stations."""
    dx = x1 - x0
    points = [(x0 + f * dx, y) for f, y in
              [(0.2, y0), (0.4, y0), (0.6, y1), (0.8, y1), (1.0, y1)]]
    return path.bezier(points, includeCurrent=True)


def outline():
    radius = GRIP_H / 2
    path = cq.Workplane("XY").workplane(offset=-B / 2)
    path = path.moveTo(0, HEAD_R).lineTo(0.400, HEAD_R)
    path = transition(path, 0.400, HEAD_R, 2.100, H / 2)
    path = path.lineTo(17.600, H / 2)
    path = transition(path, 17.600, H / 2, 20.000, radius)
    path = path.lineTo(24, radius).threePointArc((24 + radius, 0), (24, -radius))
    path = path.lineTo(20, -radius)
    path = transition(path, 20, -radius, 17.600, -H / 2)
    path = path.lineTo(2.100, -H / 2)
    path = transition(path, 2.100, -H / 2, 0.400, -HEAD_R)
    return path.lineTo(0, -HEAD_R).threePointArc((-HEAD_R, 0), (0, HEAD_R)).close()


def horizontal_edges(solid):
    return [e for e in solid.Edges() if e.BoundingBox().zlen < 2e-6]


def rounded_drive_segment(z, height):
    return (cq.Workplane("XY").workplane(offset=z)
            .rect(DRIVE, DRIVE).extrude(height).edges("|Z").fillet(DRIVE_CORNER).val())


def make_structural_body():
    """Integral circular R.100 at the drive; exact tangency to the socket land.

    Sweep the quarter circle over the four flat walls and revolve it at each
    rounded corner. This avoids a near-zero-height face at the clamp boundary.
    """
    top = B / 2 + DRIVE_FILLET
    head = B / 2
    half = DRIVE / 2
    flat = half - DRIVE_CORNER

    def shoulder_section(y):
        arc = cq.Edge.makeEllipse(DRIVE_FILLET, DRIVE_FILLET, cq.Vector(half + DRIVE_FILLET, y, top),
                                  cq.Vector(0, -1, 0), cq.Vector(1, 0, 0), 180, 270)
        bottom = cq.Vector(half, y, head)
        return cq.Wire.assembleEdges([arc, cq.Edge.makeLine(arc.endPoint(), bottom),
                                      cq.Edge.makeLine(bottom, arc.startPoint())])

    strip = cq.Solid.extrudeLinear(shoulder_section(-flat), [], cq.Vector(0, 2 * flat, 0))
    corner = cq.Solid.revolve(shoulder_section(flat), [], 90,
                              cq.Vector(flat, flat, 0), cq.Vector(flat, flat, 1))
    segments = [shape.rotate((0, 0, 0), (0, 0, 1), angle)
                for angle in (0, 90, 180, 270) for shape in (strip, corner)]
    core = rounded_drive_segment(head, FIX_Z - head).fuse(*segments).clean()
    blank = outline().extrude(B).val()
    blank = blank.fillet(EDGE_R, horizontal_edges(blank))
    upper = rounded_drive_segment(FIX_Z, B / 2 + DRIVE_HEIGHT - FIX_Z)
    return blank.fuse(core, upper).Solids()[0]


def make_baseline():
    beam = cq.Solid.makeBox(16.225, 0.450, 0.500, cq.Vector(-0.225, -0.225, -0.250))
    lower = cq.Solid.makeBox(DRIVE, DRIVE, 0.100,
                             cq.Vector(-DRIVE / 2, -DRIVE / 2, 0.250))
    upper = cq.Solid.makeBox(DRIVE, DRIVE, 0.400,
                             cq.Vector(-DRIVE / 2, -DRIVE / 2, FIX_Z))
    return beam.fuse(lower).fuse(upper).Solids()[0]


def checked_step(solid, name):
    if not solid.isValid() or len(solid.Solids()) != 1:
        raise ValueError(f"{name} is not a valid single solid")
    path = OUTPUT / name
    cq.exporters.export(solid.scale(MM), str(path))
    imported = cq.importers.importStep(str(path)).val()
    if len(imported.Solids()) != 1 or not imported.isValid():
        raise ValueError(f"STEP round-trip failed for {name}")
    if abs(imported.Volume() / (MM ** 3) - solid.Volume()) > 0.00005:
        raise ValueError(f"Unexpected volume change on STEP export for {name}")


def flat_block(x0, x1, width, z0, z1, inset):
    block = cq.Solid.makeBox(x1 - x0, width, z1 - z0, cq.Vector(x0, -width / 2, z0))
    return block.fillet(inset, block.Edges())


def little_box(x0, y0, z0, dx, dy, dz):
    return cq.Solid.makeBox(dx, dy, dz, cq.Vector(x0, y0, z0))


def circle_point(radius, radians):
    return (ARC_CENTER_X + radius * math.cos(radians), radius * math.sin(radians))


def annular_sector(inner, outer, half_angle, height, thickness):
    a = math.radians(half_angle)
    return (cq.Workplane("XY").workplane(offset=height).moveTo(*circle_point(inner, -a))
            .lineTo(*circle_point(outer, -a))
            .threePointArc(circle_point(outer, 0), circle_point(outer, a))
            .lineTo(*circle_point(inner, a))
            .threePointArc(circle_point(inner, 0), circle_point(inner, -a))
            .close().extrude(thickness))


def make_accessories(scale_throw=None, calibration=None):
    # Attach the socketed locator to the back of the head.  It touches the body at
    # z=-.250 and has no torque-carrying role.  The tube seats .61 in into the blind bore.
    foot = flat_block(-0.375, 0.405, 0.410, -0.765, -0.250, 0.047)
    bore = cq.Solid.makeCylinder(0.1105, 0.6251, cq.Vector(0.4051, 0, POINTER_Z), cq.Vector(-1, 0, 0))
    foot = foot.cut(bore).Solids()[0]
    start, end = -0.205, 18.48
    outer_r, inner_r = 0.21875 / 2, 0.21875 / 2 - 0.020
    tube = cq.Solid.makeCylinder(outer_r, end - start, cq.Vector(start, 0, POINTER_Z), cq.Vector(1, 0, 0))
    inside = cq.Solid.makeCylinder(inner_r, end - start, cq.Vector(start, 0, POINTER_Z), cq.Vector(1, 0, 0))
    tube = tube.cut(inside).Solids()[0]
    pin = cq.Solid.makeCylinder(inner_r - 0.001, 0.200, cq.Vector(end - 0.200, 0, POINTER_Z), cq.Vector(1, 0, 0))
    # Rake the pointer towards the scale to reduce parallax. Its closest edge
    # clears the bare plate by .045 in; the reference tube stays farther away.
    root_wire = cq.Wire.makeCircle(outer_r, cq.Vector(end, 0, POINTER_Z), cq.Vector(1, 0, 0))
    nose_wire = cq.Wire.makeCircle(0.010, cq.Vector(SCALE_X, 0, -0.440), cq.Vector(1, 0, 0))
    tip = cq.Solid.makeLoft([root_wire, nose_wire], ruled=True)
    tip = tip.fuse(pin).Solids()[0]

    # The index plate is a .065-in sheet with a .070-in central stand-off.
    # Viewed from the back, the needle is in front of the sheet's white markings.
    plate = (annular_sector(PLATE_R_IN, PLATE_R_OUT, PLATE_HALF_ANGLE, -0.385, 0.065)
             .edges("|Z").fillet(PLATE_END_FILLET).val())
    pad = flat_block(18.77, 19.32, 0.35, -0.321, -0.250, 0.015)
    plate = plate.fuse(pad).Solids()[0]

    # Indication marks are thin, separate ink solids so the structural analysis
    # never sees a cosmetic notch.  +/-600 in-lbf uses the full calibrated sweep.
    marks = []
    def legend(label, x, y, height, direction):
        plane = cq.Plane(origin=(x, y, -0.385), xDir=(*direction, 0), normal=(0, 0, -1))
        outlines = (cq.Workplane(plane).text(label, height, 0.0015, font="Arial",
                                             kind="bold", combine=False).val())
        marks.extend(outlines.Solids())

    if calibration is None:
        calibration = json.loads((OUTPUT / "scale-layout.json").read_text(encoding="utf-8"))
    correction = 1.0 if scale_throw is None else scale_throw / calibration["mean_projected_half_span_in"]
    ticks = []
    for mark in calibration["marks"]:
        torque, tip_x = mark["torque_in_lbf"], mark["tip_in_plate_in"][0]
        y = mark["tip_in_plate_in"][1] * correction
        major = torque % 200 == 0
        theta = math.atan2(y, tip_x - ARC_CENTER_X)
        ux, uy = math.cos(theta), math.sin(theta)
        # Every radial tick crosses its own measured needle position.
        # Unite the marks with the narrow circular track to avoid overlapping ink solids.
        end = 0.205 if major else (0.130 if torque % 100 == 0 else 0.080)
        corners = [(tip_x + along * ux - across * uy, y + along * uy + across * ux)
                   for along, across in [(-.010, -.006), (end, -.006), (end, .006), (-.010, .006)]]
        ticks.append(cq.Workplane("XY").workplane(offset=-.387).polyline(corners).close().extrude(.002).val())
        if major:
            legend(str(abs(torque)), tip_x + .348 * ux, y + .348 * uy, 0.104, (ux, uy))
    rail = annular_sector(TRACK_RADIUS - .005, TRACK_RADIUS + .005, 13.24, -.387, .002).val()
    marks.append(rail.fuse(*ticks).clean())
    for sign in (-1, 1):
        theta = math.radians(sign * 16.70)
        tx, ty = circle_point(5.170, theta)
        legend("IN-LBF", tx, ty, 0.103, (math.cos(theta), math.sin(theta)))
    grip_mark = cq.Compound.makeCompound([
        little_box(L - 0.012, -0.420, -0.252, 0.024, 0.840, 0.002),
        little_box(L - 0.012, -0.420, 0.250, 0.024, 0.840, 0.002)])
    return {"Pointer seat": foot, "Reference tube": tube, "Index tip": tip,
            "Scale plate": plate, "Scale graduations": cq.Compound.makeCompound(marks),
            "Grip center mark": grip_mark}


def metadata(solid):
    if not solid.isValid():
        raise ValueError("A CAD component failed B-rep validation")
    box = solid.BoundingBox()
    return {"volume_in3": round(solid.Volume(), 8),
            "extent_in": [[round(x, 6) for x in xyz] for xyz in
                          [(box.xmin, box.ymin, box.zmin), (box.xmax, box.ymax, box.zmax)]],
            "faces": len(solid.Faces()), "solids": len(solid.Solids())}


COLORS = {"Torque body": (0.46, 0.50, 0.55), "Pointer seat": (0.20, 0.24, 0.28),
          "Reference tube": (0.55, 0.61, 0.65), "Index tip": (0.94, 0.35, 0.09),
          "Scale plate": (0.08, 0.15, 0.20), "Scale graduations": (0.92, 0.94, 0.94),
          "Grip center mark": (0.88, 0.34, 0.10)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--body-only", action="store_true")
    parser.add_argument("--accessories-only", action="store_true",
                        help="Keep the existing structural STEP files while updating the assembly")
    parser.add_argument("--scale-throw", type=float)
    args = parser.parse_args()
    base = make_baseline()
    if not args.accessories_only:
        checked_step(base, "baseline-body.step")
        print("Baseline STEP ready", flush=True)
    body = make_structural_body()
    if not args.accessories_only:
        checked_step(body, "flexure-body.step")
        cq.exporters.export(body.scale(MM), str(OUTPUT / "flexure-body.stl"),
                            tolerance=0.025, angularTolerance=0.16)
        print("Final structural STEP ready", flush=True)
    geom = {"units": "inch in data and source, mm in STEP",
            "base": metadata(base), "body": metadata(body), "scale_x_in": SCALE_X,
            "load_face_in": {"y": 0.520, "x": [20, 24], "z": [-0.190, 0.190]},
            "drive_clamp_z_in": [FIX_Z, 0.750],
            "working_span_x_in": [2.100, 17.600],
            "transition_x_in": [[0.400, 2.100], [17.600, 20.000]],
            "drive_width_in": DRIVE, "drive_corner_in": DRIVE_CORNER,
            "drive_root_in": DRIVE_FILLET, "perimeter_round_in": EDGE_R,
            "head_radius_in": HEAD_R, "beam_width_in": H, "thickness_in": B,
            "grip_width_in": GRIP_H, "load_x_in": L}
    if not args.body_only:
        calibration = json.loads((OUTPUT / "scale-layout.json").read_text(encoding="utf-8"))
        geom.update({"scale_half_span_in": args.scale_throw or calibration["mean_projected_half_span_in"],
                     "scale_basis": "manual scale override" if args.scale_throw is not None
                                     else "signed FE pointer-tip projections into the rotating plate, 600 in-lbf",
                     "min_ink_clearance_in": calibration["min_clearance_to_ink_in"],
                     "attachment": {"head_socket_engagement_in": 0.610, "tube_od_in": 0.21875,
                                    "tube_wall_in": 0.020, "scale_plate_thickness_in": 0.065},
                     "scale_geometry": {"center_xy_in": [ARC_CENTER_X, 0], "scale_track_radius_in": TRACK_RADIUS,
                                        "plate_inner_radius_in": PLATE_R_IN, "plate_outer_radius_in": PLATE_R_OUT,
                                        "half_angle_deg": PLATE_HALF_ANGLE, "end_round_in": PLATE_END_FILLET,
                                        "radial_width_in": PLATE_R_OUT - PLATE_R_IN,
                                        "marks_are_radial": True},
                     "materials": {"Torque body": "Custom 465 H950 stainless; controlled shot-peened finish",
                                   "Reference tube": "304 stainless tube",
                                   "Pointer seat, index tip and scale": "6061-T6 aluminum"}})
        components = {"Torque body": body, **make_accessories(args.scale_throw, calibration)}
        assembly = cq.Assembly(name="Horizontally indicating torque wrench")
        mesh_dir = OUTPUT / "render-mesh"
        mesh_dir.mkdir(exist_ok=True)
        geom["components"] = {}
        for name, part in components.items():
            geom["components"][name] = metadata(part)
            assembly.add(part.scale(MM), name=name, color=cq.Color(*COLORS[name]))
            cq.exporters.export(part, str(mesh_dir / (name.replace(" ", "-") + ".stl")),
                                tolerance=0.0015, angularTolerance=0.10)
        assembly.export(str(OUTPUT / "indicating-wrench.step"))
        reopened = cq.importers.importStep(str(OUTPUT / "indicating-wrench.step")).val()
        assert reopened.isValid()
        if abs(reopened.Volume() / MM ** 3 - sum(p.Volume() for p in components.values())) > 0.00015:
            raise ValueError("Assembly STEP volume check failed")
        print("Assembly STEP ready", flush=True)
    summary_name = "structural-geometry.json" if args.body_only else "geometry.json"
    with open(OUTPUT / summary_name, "w", encoding="utf-8") as stream:
        json.dump(geom, stream, indent=2)


if __name__ == "__main__":
    main()
