"""Hidden-line and face projections from the released, re-imported STEP models."""
from __future__ import annotations

import html
import json
import math
from pathlib import Path

import cadquery as cq
import numpy as np
from OCP.BRepLib import BRepLib
from OCP.BRepTools import BRepTools_WireExplorer
from OCP.HLRAlgo import HLRAlgo_Projector
from OCP.HLRBRep import HLRBRep_Algo, HLRBRep_HLRToShape
from OCP.gp import gp_Ax2, gp_Dir, gp_Pnt, gp_Trsf

ROOT = Path(__file__).resolve().parent


def read_assembly():
    model = cq.Assembly.importStep(str(ROOT / "indicating-wrench.step"), unit="INCH")
    return {name.split("/")[-1]: part.moved(location) for part, name, location, _ in model}


def hlr(part, normal, xdir=(1, 0, 0)):
    axis = gp_Ax2(gp_Pnt(), gp_Dir(*normal), gp_Dir(*xdir))
    algo = HLRBRep_Algo()
    algo.Add(part.wrapped)
    algo.Projector(HLRAlgo_Projector(axis))
    algo.Update()
    algo.Hide()
    curves = HLRBRep_HLRToShape(algo)
    layers = {}
    for layer, wrapped in [
            ("TANGENCY", curves.Rg1LineVCompound()), ("VISIBLE", curves.VCompound()),
            ("OUTLINE", curves.OutLineVCompound())]:
        if not wrapped.IsNull():
            BRepLib.BuildCurves3d_s(wrapped, 1e-7)
            layers[layer] = cq.Shape.cast(wrapped)
    return layers


def sample_edge(edge, tol=0.00028):
    if edge.Length() < 1e-8:
        return []
    points, _ = edge.sample(tol)
    if edge.IsClosed() and points:
        points.append(points[0])
    return [(p.x, p.y) for p in points]


def wire_xy(wire):
    explorer = BRepTools_WireExplorer(wire.wrapped)
    points = []
    while explorer.More():
        edge = cq.Edge(explorer.Current())
        p = cq.Vertex(explorer.CurrentVertex()).Center()
        sampled = sample_edge(edge, 0.00012)
        if sampled and (abs(sampled[-1][0] - p.x) + abs(sampled[-1][1] - p.y)
                        < abs(sampled[0][0] - p.x) + abs(sampled[0][1] - p.y)):
            sampled.reverse()
        points.extend(sampled)
        explorer.Next()
    return points


def curve(points, transform, closed=False):
    coords = [transform(x, y) for x, y in points]
    if len(coords) < 2:
        return ""
    return "M" + "L".join(f"{x:.3f},{y:.3f}" for x, y in coords) + ("Z" if closed else "")


def dark_scale(part, transform, color, stroke="none", thickness=0):
    pieces = []
    for face in part.Faces():
        box = face.BoundingBox()
        if face.geomType() != "PLANE" or box.zlen > 5e-6 or face.normalAt().z > -.999:
            continue
        # For the scale back, select the large, visible, front sheet only.
        if stroke != "none" and face.Area() < 1.0:
            continue
        path = " ".join(curve(wire_xy(w), transform, True) for w in face.Wires())
        if path.strip():
            pieces.append(f'<path d="{path}" fill="{color}" fill-rule="evenodd" stroke="{stroke}" stroke-width="{thickness}"/>')
    return "\n".join(pieces)


def svg_document(width, height, title, desc, content, viewbox=None):
    viewbox = viewbox or f"0 0 {width} {height}"
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="{viewbox}" '
            f'role="img" aria-labelledby="title desc"><title id="title">{html.escape(title)}</title>'
            f'<desc id="desc">{html.escape(desc)}</desc>\n{content}\n</svg>')


def emit_face(parts):
    uv = lambda x, y: (100 + 250 * (x - 18.45), 520 + 250 * y)
    content = dark_scale(parts["Scale plate"], uv, "#183e4b", "#477884", 1.2)
    content += dark_scale(parts["Scale graduations"], uv, "#fbfbef")
    (ROOT / "scale-face.svg").write_text(svg_document(
        500, 1040, "Curved torque scale", "Front face and calibrated permanent markings projected from the assembly STEP. "
        "Local inch coordinates transform with u=100+250(x-18.45), v=520+250y.", content), encoding="utf-8")


def svg_projection(layers, w, h, limits=None, roller=0, monochrome=False):
    paths = []
    for layer, shape in layers.items():
        for edge in shape.Edges():
            points = sample_edge(edge, 0.0006)
            if len(points) > 1:
                paths.append((layer, points))
    r = math.radians(roller)
    rot = lambda x, y: (x * math.cos(r) - y * math.sin(r), x * math.sin(r) + y * math.cos(r))
    paths = [(name, [rot(x, y) for x, y in p]) for name, p in paths]
    if limits is None:
        xy = np.array([point for _, path in paths for point in path])
        xmin, ymin = xy.min(axis=0)
        xmax, ymax = xy.max(axis=0)
    else:
        xmin, ymin, xmax, ymax = limits
    k = min((w - 24) / (xmax - xmin), (h - 24) / (ymax - ymin))
    cx = (xmin + xmax) / 2
    cy = (ymin + ymax) / 2
    transform = lambda x, y: (w / 2 + (x - cx) * k, h / 2 - (y - cy) * k)
    items = []
    width = {"TANGENCY": .70, "VISIBLE": 1.35, "OUTLINE": 2.0}
    color = {"TANGENCY": "#567984", "VISIBLE": "#183944", "OUTLINE": "#102d39"}
    for name, path in paths:
        d = curve(path, transform)
        items.append(f'<path d="{d}" fill="none" stroke="{color[name]}" stroke-width="{width[name]}" '
                     'stroke-linejoin="round" stroke-linecap="round"/>')
    return "\n".join(items)


def projected_rated_parts(parts):
    data = json.loads((ROOT / "scale-layout.json").read_text(encoding="utf-8"))
    matrix = np.array(data["head_to_plate_transforms"]["600"])
    transform = gp_Trsf()
    transform.SetValues(*matrix[:3].ravel())
    loc = cq.Location(transform)
    return {**{name: parts[name] for name in ["Scale plate", "Scale graduations"]},
            **{name: parts[name].moved(loc) for name in ["Reference tube", "Index tip"]}}


def plate_face_at_load(parts):
    rated = projected_rated_parts(parts)
    # Crop the reference tube to its last portion so the drawing centers on the scale.
    window = cq.Solid.makeBox(3.4, 5.4, 2.0, cq.Vector(17.35, -2.7, -1.15))
    tube_detail = rated["Reference tube"].intersect(window)
    return cq.Compound.makeCompound([tube_detail, rated["Index tip"], rated["Scale plate"], rated["Scale graduations"]])


def main():
    parts = read_assembly()
    emit_face(parts)
    print("CAD scale face written", flush=True)
    whole = cq.Compound.makeCompound(list(parts.values()))
    layers = hlr(whole, (-1., -1., -1.))
    art = svg_projection(layers, 1560, 490, roller=11)
    (ROOT / "assembly-isometric.svg").write_text(svg_document(
        1560, 490, "Complete torque wrench assembly", "Visible edges from the released assembly STEP, "
        "with hidden edges removed by OpenCascade.", art), encoding="utf-8")
    print("Complete assembly projection written", flush=True)
    rated = plate_face_at_load(parts)
    detail = svg_projection(hlr(rated, (0, 0, -1)), 690, 760)
    (ROOT / "rated-scale-detail.svg").write_text(svg_document(
        690, 760, "Curved scale at positive rated torque", "CAD view of the pointer at plus 600 in-lbf, "
        "with the rigid head motion transformed into the handle-mounted scale frame.", detail), encoding="utf-8")
    print("Rated scale projection written", flush=True)


if __name__ == "__main__":
    main()
