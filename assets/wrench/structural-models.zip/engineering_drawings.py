"""Plot editable ANSI B engineering drawings directly from the released STEP.

All projected CAD blocks retain their actual dimensions in inches. Sheet views
are scaled block references. Linear, radial and angular dimensions are DXF
DIMENSION entities. The PDF and SVG sheets are plots of the very same DXFs.
"""
from __future__ import annotations

import math
from pathlib import Path

import cadquery as cq
import ezdxf
import fitz
import numpy as np
from cadquery.occ_impl.exporters.dxf import DxfDocument
from ezdxf.addons.drawing import Frontend, RenderContext, config, layout, pymupdf, svg
from ezdxf.enums import TextEntityAlignment
from ezdxf.math import BoundingBox2d

from cad_drawing_geometry import hlr, plate_face_at_load, read_assembly

ROOT = Path(__file__).resolve().parent
SHEET_W, SHEET_H = 17, 11
LAYERS = {
    "OUTLINE": ((20, 42, 53), 35), "VISIBLE": ((30, 48, 56), 25),
    "TANGENCY": ((100, 121, 126), 13), "DIMENSIONS": ((19, 91, 100), 18),
    "CENTER": ((96, 137, 141), 13), "NOTES": ((25, 47, 55), 18),
    "BORDER": ((93, 122, 127), 20), "TITLES": ((19, 43, 51), 25),
}


def ln(space, a, b, layer="BORDER"):
    return space.add_line(a, b, dxfattribs={"layer": layer})


def txt(space, at, label, height=.125, layer="NOTES", right=False, center=False):
    align = TextEntityAlignment.MIDDLE_CENTER if center else (
        TextEntityAlignment.MIDDLE_RIGHT if right else TextEntityAlignment.MIDDLE_LEFT)
    return space.add_text(label, dxfattribs={"height": height, "style": "DRAWING-TEXT",
                                            "layer": layer}).set_placement(at, align=align)


class Sheet:
    def __init__(self, title, sheet_id, subtitle):
        self.doc = ezdxf.new("R2013", setup=True, units=ezdxf.units.IN)
        self.doc.header["$MEASUREMENT"] = 0
        self.doc.header["$LUNITS"] = 2
        self.doc.header["$LUPREC"] = 4
        self.doc.styles.new("DRAWING-TEXT", dxfattribs={"font": "arial.ttf"})
        for name, (rgb, weight) in LAYERS.items():
            entry = self.doc.layers.new(name, dxfattribs={"color": 7, "lineweight": weight})
            entry.rgb = rgb
        self.doc.dimstyles.new("INCH", dxfattribs={
            "dimtxt": .115, "dimasz": .074, "dimgap": .028, "dimexe": .040, "dimexo": .030,
            "dimdec": 3, "dimzin": 0, "dimaunit": 0, "dimadec": 1, "dimtad": 1,
            "dimclrd": 0, "dimclre": 0, "dimclrt": 0, "dimdsep": ord("."),
            "dimtxsty": "DRAWING-TEXT", "dimlunit": 2, "dimtih": 0, "dimtoh": 0})
        self.space = self.doc.modelspace()
        self.converter = DxfDocument(doc_units=ezdxf.units.IN)
        frame = [(.28, .29), (16.72, .29), (16.72, 10.71), (.28, 10.71)]
        self.space.add_lwpolyline(frame, close=True, dxfattribs={"layer": "BORDER"})
        txt(self.space, (.57, 10.26), title, .29, "TITLES")
        txt(self.space, (16.43, 10.26), "MAE 3270   /   ENGINEERING DESIGN", .14, "DIMENSIONS", right=True)
        ln(self.space, (.28, 9.86), (16.72, 9.86))
        ln(self.space, (.28, 1.05), (16.72, 1.05))
        txt(self.space, (.58, .69), "GRANT CORSO", .15, "TITLES")
        txt(self.space, (3.18, .69), subtitle, .125)
        txt(self.space, (16.41, .69), f"{sheet_id}   /   ANSI B   /   INCHES", .13, "DIMENSIONS", right=True)
        self.bounds = BoundingBox2d([(0, 0), (SHEET_W, SHEET_H)])

    def block(self, name, shapes, view, xdir=(1, 0, 0)):
        block = self.doc.blocks.new(name)
        self.converter.msp = block
        for layer, edges in hlr(shapes, view, xdir).items():
            self.converter.add_shape(cq.Workplane("XY").newObject([edges]), layer=layer)
        return block

    def place(self, block, at, scale, reference=(0, 0)):
        x, y = at
        u, v = reference
        self.space.add_blockref(block.name, (x - scale * u, y - scale * v),
                                dxfattribs={"xscale": scale, "yscale": scale, "zscale": scale})

    def write(self, stem, web_name):
        paperspace = self.doc.layouts.get("Layout1")
        self.doc.layouts.rename("Layout1", "ANSI B")
        paperspace.page_setup(size=(17, 11), margins=(0, 0, 0, 0), units="inch", scale=(1, 1))
        paperspace.add_viewport(center=(8.5, 5.5), size=(17, 11),
                                view_center_point=(8.5, 5.5), view_height=11)
        self.doc.set_modelspace_vport(height=12, center=(8.5, 5.5))
        path = ROOT / (stem + ".dxf")
        self.doc.saveas(path)
        doc = ezdxf.readfile(path)
        audit = doc.audit()
        if audit.errors:
            raise RuntimeError(f"{path.name} has {len(audit.errors)} DXF audit errors")
        cfg = config.Configuration(background_policy=config.BackgroundPolicy.WHITE,
                                   max_flattening_distance=.0007)
        page = layout.Page(17, 11, layout.Units.inch)
        settings = layout.Settings(fit_page=True, page_alignment=layout.PageAlignment.MIDDLE_CENTER,
                                   min_stroke_width=.055)
        for backend, target in [(pymupdf.PyMuPdfBackend(), "pdf"), (svg.SVGBackend(), "svg")]:
            Frontend(RenderContext(doc), backend, config=cfg).draw_layout(doc.modelspace(), finalize=True)
            if target == "pdf":
                (ROOT / (stem + ".pdf")).write_bytes(backend.get_pdf_bytes(page, settings=settings, render_box=self.bounds))
            else:
                (ROOT / web_name).write_text(backend.get_string(page, settings=settings, render_box=self.bounds),
                                             encoding="utf-8")
        print(stem, "audited and plotted", flush=True)


def dim(block, scale, p1, p2, base, text="<>", vertical=False, text_location=None):
    result = block.add_linear_dim(base=base, p1=p1, p2=p2, text=text, angle=90 if vertical else 0,
                                  dimstyle="INCH", location=text_location, override={"dimscale": 1 / scale},
                                  dxfattribs={"layer": "DIMENSIONS"})
    result.render()


def radial(block, scale, center, radius, angle, label):
    result = block.add_radius_dim(center=center, radius=radius, angle=angle,
                                  dimstyle="INCH", text=label, override={
                                      "dimscale": 1 / scale, "dimtix": 1, "dimcen": 0},
                                  dxfattribs={"layer": "DIMENSIONS"})
    result.render()


def dashed(space, start, end, step=.20, gap=.08):
    start, end = np.array(start), np.array(end)
    length = np.linalg.norm(end - start)
    unit = (end - start) / length
    for v in np.arange(0, length, step + gap):
        ln(space, start + v * unit, start + min(length, v + step) * unit, "CENTER")


def heading(space, x, y, wording):
    txt(space, (x, y), wording, .139, "DIMENSIONS")


def section_x(shape, x):
    return shape.intersect(cq.Solid.makeBox(.0004, 3, 2, cq.Vector(x, -1.5, -.75))).Solids()[0]


def structural(parts):
    sh = Sheet("Torque wrench  /  Structural body", "TW-01   /   1 OF 2", "Custom 465 stainless steel  /  H950")
    model = parts["Torque body"]
    plan = sh.block("BODY-PLAN", model, (0, 0, 1))
    s = .5
    dashed(plan, (-.82, 0), (24.75, 0))
    for x in [0, 19, 22]:
        dashed(plan, (x, -.84), (x, .85))
    dim(plan, s, (0, .55), (22, .52), (0, 2.04), "<>  LOAD CENTER")
    dim(plan, s, (20, .52), (24, .52), (20, 1.05), text_location=(21.25,1.32))
    dim(plan, s, (0, -.55), (19, -.38), (0, -1.00), "<>  SCALE STATION")
    dim(plan, s, (-.55, 0), (24.52, 0), (0, -1.85), "<>  OVERALL")
    sh.place(plan, (2.51, 8.00), s)
    heading(sh.space, .61, 9.49, "PLAN   /   1:2")
    ln(sh.space, (.55, 6.80), (16.44, 6.80))
    heading(sh.space, .61, 6.53, "DRIVE ELEVATION   /   2:1")
    heading(sh.space, 4.58, 6.53, "DRIVE SECTION   /   2:1")
    heading(sh.space, 7.44, 6.53, "FLEXURE   /   3:1")
    heading(sh.space, 11.34, 6.53, "GRIP   /   3:1")

    head = model.intersect(cq.Solid.makeBox(1.42, 2.0, 1.2, cq.Vector(-.60, -1, -.30)))
    elev = sh.block("DRIVE-ELEVATION", head, (0, -1, 0))
    dim(elev, 2, (.1875, .25), (.1875, .75), (.49, .25), vertical=True)
    dim(elev, 2, (.1875, .35), (.1875, .75), (.72, .35), vertical=True)
    sh.place(elev, (1.85, 4.56), 2)
    txt(sh.space, (.72, 3.76), "0.400 socket engagement", .113)
    txt(sh.space, (.72, 3.53), "R0.100 drive shoulder", .113)
    cut = model.intersect(cq.Solid.makeBox(.7, .7, .002, cq.Vector(-.35, -.35, .60)))
    sq = sh.block("DRIVE-CROSS-SECTION", cut, (0, 0, 1))
    dim(sq, 2, (-.1875,.16),(.1875,.16), (0,.326))
    sh.place(sq, (5.53, 5.04), 2)
    txt(sh.space, (4.57, 3.76), "3/8 in across flats", .113)
    txt(sh.space, (4.57, 3.53), "R0.025 at four corners", .113)
    beam = sh.block("FLEXURE-SECTION", section_x(model, 6.), (1, 0, 0), (0, 1, 0))
    dim(beam, 3, (-.18,.19), (.18,.19), (0,.34))
    dim(beam, 3, (-.12,-.25), (-.12,.25), (-.306,0), vertical=True)
    sh.place(beam, (8.64, 5.02), 3)
    txt(sh.space, (7.43, 3.76), "Section at x = 6.000", .113)
    txt(sh.space, (7.43, 3.53), "R0.060 edge rounds", .113)
    grip = sh.block("GRIP-SECTION", section_x(model, 22.), (1,0,0),(0,1,0))
    dim(grip, 3, (-.52,.19),(.52,.19), (0,.34))
    sh.place(grip, (13.52, 5.02), 3)
    txt(sh.space, (11.34, 3.76), "Section at x = 22.000", .113)
    txt(sh.space, (11.34, 3.53), "R0.520 grip end cap in plan", .113)

    ln(sh.space, (.55, 3.27), (16.44, 3.27))
    heading(sh.space, .61, 2.97, "PROFILE STATIONS FROM THE DRIVE AXIS")
    for (x, val, label) in [(0.61,"R0.550","Rounded head"), (3.37,"0.400 to 2.100","Head transition"),
                            (6.65,"2.100 to 17.600","Constant flexure"), (10.32,"17.600 to 20.000","Grip transition"),
                            (13.96,"20.000 to 24.000","Loading flat")]:
        txt(sh.space, (x, 2.49), val, .151, "TITLES")
        txt(sh.space, (x, 2.16), label, .123)
    txt(sh.space, (.61, 1.53), "Both profile transitions meet the straight sections with continuous slope and curvature.",
        .125)
    sh.write("torque-body-drawing", "dimensioned-model.svg")


def scale_assembly(parts):
    sh = Sheet("Torque wrench  /  Indicator assembly", "TW-02   /   2 OF 2",
               "6061-T6 scale and index tip  /  304 stainless reference tube")
    whole = cq.Compound.makeCompound(list(parts.values()))
    view = np.array([-1., -1., -1.]); view /= np.linalg.norm(view)
    x = np.array([1.,0,0]); x -= x.dot(view)*view; x /= np.linalg.norm(x)
    up = np.cross(view,x)
    rotated = x*math.cos(math.radians(5))-up*math.sin(math.radians(5))
    iso = sh.block("ASSEMBLY-AXONOMETRIC", whole, view, rotated)
    heading(sh.space, .61, 9.51, "COMPLETE ASSEMBLY   /   1:2")
    sh.place(iso, (.93, 7.75), .50)
    ln(sh.space, (11.96, 7.02), (11.96, 9.65))
    heading(sh.space, 12.15, 9.51, "POINTER CLEARANCE   /   2:1")
    local = cq.Solid.makeBox(1.22, 4.5, 1.35, cq.Vector(18.34,-2.25,-.85))
    edge_parts = [parts[n].intersect(local) for n in ["Torque body","Scale plate","Reference tube","Index tip"]]
    edge_view = sh.block("CLEARANCE-ELEVATION", cq.Compound.makeCompound(edge_parts), (0,-1,0))
    sh.place(edge_view, (13.61, 8.78), 2, (19,0))
    txt(sh.space, (12.16, 7.13), "0.045 tip to bare plate at zero torque", .115)
    ln(sh.space, (.55, 6.85), (16.44, 6.85))
    heading(sh.space, .61, 6.53, "GRADUATED SCALE   /   1:1")
    heading(sh.space, 8.47, 6.53, "RATED POINTER POSITION   /   1:1")
    label_parts = cq.Compound.makeCompound([parts["Scale plate"],parts["Scale graduations"]])
    face = sh.block("INDICATOR-FACE", label_parts, (0,0,-1))
    cx=13.960
    for a in [-19.5,19.5]:
        ang=math.radians(a)
        q=(cx+5.75*math.cos(ang), 5.75*math.sin(ang))
        dashed(face, (cx,0),q,.18,.08)
    # The radii are native dimensions of the real annular face in this block.
    radial(face,1,(cx,0),4.740,-10,"<>  INNER")
    radial(face,1,(cx,0),5.600,12.0,"<>  OUTER")
    radial(face,1,(cx,0),5.040,-3.8,"<>  TRACK")
    a=math.radians(19.5)
    end1=(cx+4*math.cos(a),-4*math.sin(a)); end2=(cx+4*math.cos(a),4*math.sin(a))
    face.add_angular_dim_3p(base=(cx+1.35,0), center=(cx,0), p1=end1, p2=end2,text_rotation=0,
        dimstyle="INCH",override={"dimscale":1},dxfattribs={"layer":"DIMENSIONS"}).render()
    sh.place(face,(6.16,4.05),1,(19,0))
    txt(sh.space, (.64, 1.81), "Arc center at (13.960, 0). Four R0.105 end rounds.", .116)
    txt(sh.space, (.64, 1.54), "0.065 sheet on a 0.070 stand-off. Radial band width 0.860.", .116)
    ln(sh.space, (8.02,1.27),(8.02,6.64))
    rated = sh.block("RATED-READOUT",plate_face_at_load(parts),(0,0,-1))
    sh.place(rated,(11.57,4.05),1,(19,0))
    txt(sh.space, (12.75, 5.20), "600 in-lbf", .166, "TITLES")
    txt(sh.space, (12.75, 4.89), "Positive load case", .117)
    txt(sh.space, (12.75, 4.21), "50 in-lbf per division", .121)
    txt(sh.space, (12.75, 3.90), "0.130 tip setback", .121)
    txt(sh.space, (12.75, 3.58), "1.136 plate half-span", .121)
    txt(sh.space, (8.49, 1.81), "7/32 OD reference tube, 0.020 wall, 0.610 socket engagement.", .116)
    txt(sh.space, (8.49, 1.54), "The scale follows the handle and the reference tube follows the head.", .116)
    sh.write("indicator-assembly-drawing","indicator-layout.svg")


if __name__ == "__main__":
    parts = read_assembly()
    structural(parts)
    scale_assembly(parts)
    out = fitz.open()
    for name in ["torque-body-drawing", "indicator-assembly-drawing"]:
        with fitz.open(ROOT / (name + ".pdf")) as page:
            out.insert_pdf(page)
    out.set_metadata({"title":"Torque wrench engineering drawings","author":"Grant Corso",
                      "subject":"Dimensioned projections of the released STEP assembly and torque body"})
    out.save(ROOT / "wrench-engineering-drawings.pdf", deflate=True, garbage=4)
